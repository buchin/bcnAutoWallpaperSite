Theme Name: Braintied
Theme URI: http://www.wpdesigner.com
Description: Braintied Wordpress theme created by Small Potato
Version: 1.0
Author: Small Potato
Author URI: http://www.wpdesigner.com/

	Released under GPL.

===========
INSTALLATION
===========

- Unzip the downloaded file. You'll get a folder named "braintied"
- Upload the entire "braintied" folder to your 'wp-content/themes/" folder
- Login into WordPress administration
- Click on the 'Presentation" tab
- Click on the "braintied" theme thumbnail/screenshot or title

That's it. Go back to the front page of your blog and hit refresh to see your newly installed theme.

=============
TIP
=============

- Use alignleft or alignright to make your images float left or right. For example: <img src="yourimage.gif" class="alignleft">