<div id="footer">
<p>
<?php
if(function_exists(bstat_todayrefs) && !is_home()){
echo 'recenlty searched: ';
bstat_todayrefs(20,'',' ');
echo '<br/>random posts: ';
random_posts(10, 30, '', ', ', '', '</p><br/>',false, false); 
echo '<br/>popular today: ';
bstat_todaypop(20, '', ' ');

}
?>
</p>
<ul class="menu">
<li><a href="http://masbuchin.com">Proxy</a></li>
<?php wp_list_pages('title_li='); ?>
</ul>

<p style="clear:both;"><?php bloginfo('name'); ?> <?php _e('is proudly powered by <a href="http://www.wordpress.org/" title="WordPress" rel="nofollow">WordPress</a> and <a href="http://www.wpdesigner.com" title="WordPress Themes" rel="nofollow">WPDesigner</a>.'); ?></p>
<?php wp_footer(); ?>

</div></div>
<?php // this is the part that makes the bstats plugin work...
    global $id;
    if (!is_single()) $id = 0;
    bstat_hitit($id, "read");
    ?>
<div style="text-align:center;"><?php if(!is_home()){?>

<?php } ?></div>
<script src="http://27196.hittail.com/mlt.js" type="text/javascript"></script>

<script type="text/javascript">var infolink_pid = 10641;</script>
<script type="text/javascript" src="http://resources.infolinks.com/js/infolinks_main.js"></script>

</div>
<!-- Start of StatCounter Code -->
<script type="text/javascript">
var sc_project=4867328; 
var sc_invisible=1; 
var sc_partition=57; 
var sc_click_stat=1; 
var sc_security="a9435245"; 
</script>

<script type="text/javascript"
src="http://www.statcounter.com/counter/counter.js"></script><noscript><div
class="statcounter"><a title="web counter"
href="http://www.statcounter.com/" target="_blank"><img
class="statcounter"
src="http://c.statcounter.com/4867328/0/a9435245/1/"
alt="web counter" ></a></div></noscript>

<script type="text/javascript" src="http://widgets.amung.us/classic.js"></script><script type="text/javascript">WAU_classic('uro20e560tqv')</script>

<!-- End of StatCounter Code -->

</body>
</html>