<?php get_header(); ?>

<div class="page">

	<div class="post">
<p><script type="text/javascript"><!--
google_ad_client = "pub-0127266326569641";
/* 468x15, masbuchin */
google_ad_slot = "6894667665";
google_ad_width = 468;
google_ad_height = 15;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></p><br/>

	<div class="title-item">
<?php _e('404 Error&#58; Not Found'); ?>
<p><script type="text/javascript"><!--
google_ad_client = "pub-0127266326569641";
/* 300x250, masbuchin */
google_ad_slot = "4856166736";
google_ad_width = 300;
google_ad_height = 250;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</p>

<script type="text/javascript" src="http://jambovideonetwork.com/playlist_player_page_js_body.php?pubsite_id=7452"></script>

	</div>

	</div>

</div>

<?php get_footer(); ?>