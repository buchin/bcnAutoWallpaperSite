=== WP Answers ===
Contributors: anieto2k
Donate link: 
Tags: comments, vote
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 0.1d

Convert your Wordpress into a comunity of questions and answers.

== Description ==

Using a comments vote system you can order the comments by votes getting the focus to the most voted comment by the users. Similar than StackOverFlow or Yahoo! Questions.
You can use it with any theme, only need add some css code into your style.css for integrate with the design.

== Installation ==

Simple:

1. Descompress the file
2. Upload the directory `wp-answers/` to the `wp-content/plugins/` directory.
3. Activate the plugin
4. Goto Settings > Wp-Answers to change your settings

== Frequently Asked Questions ==

== Screenshots ==
<h3>Example with P2 theme</h3>
`http://www.anieto2k.com/wp-content/uploads/2009/11/wp-answers.jpg`

<h3>Options</h3>
`http://www.anieto2k.com/wp-content/uploads/2009/11/wp-answers-options1.jpg`

== Changelog ==

= 0.1a =
 Posibility of asociate to a category

= 0.1b =
 Reestructure the files

= 0.1c =
 Increase the usability

= 0.1d = 
 List of articles order by karma (sum of comments karma)
 Posibility of clear karma user
 Posibility of clear karma comments

== Arbitrary section ==

== A brief Markdown Example ==