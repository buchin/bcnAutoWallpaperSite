=== Wordpress Wiki ===
Contributors: Dan Milward, Thomas Howard, Allen Han
Donate link: http://www.instinct.co.nz/
Tags: wiki
Requires at least: 2.6
Tested up to: 2.7

Tired of using Media Wiki? Sick of fighting with WordPress to get your own documentation project happening? 

== Description ==

Tired of using Media Wiki? Sick of fighting with WordPress to get your own documentation project happening?

If so then WordPress Wiki Plugin is the answer for you. The new WordPress Wiki plugin made by the guys at Instinct (who brought you the famous <a title="wordpress e-commerce plugin" href="http://www.instinct.co.nz/e-commerce">Wordpress e-Commerce Plugin</a>) have developed a new plugin that adds Wiki functionality to your WordPress powered website.

== Installation ==

1. Copy the Plugin files to <code>wp-content/plugins/<code>

2. Mark the posts or pages as wiki posts or pages, this is done in the edit posts or pages page. The checkbox is available underneath the main TinyMCE box where you write your post or page content.

== Readme Validator ==

This readme was made using:
wordpress.org/extend/plugins/about/validator/

Totally totally cool tool!!
